#!/bin/bash
cd /workspace/gabriel-family-clinic  
npm run build
