export const dynamic = 'force-dynamic';
export const runtime = 'edge';

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
